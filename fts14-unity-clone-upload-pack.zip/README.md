# FTS 14 Unity Clone
This is a sample Unity project structure ready for GitHub upload.